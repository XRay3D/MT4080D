#ifndef MI_H
#define MI_H

#include "mt4080.h"
#include "relay.h"
#include <QObject>

class MI {
public:
    MI();
    ~MI();
    static Relay* rel;
    static MT4080* mt;
};

#endif // MI_H
