#include "relay.h"

template <class T>
void endswap(T* objp) //little endian <> big endian
{
    unsigned char* memp = reinterpret_cast<unsigned char*>(objp);
    std::reverse(memp, memp + sizeof(T));
}

RELAY::RELAY(QObject* parent)
    : QSerialPort(parent)
{
    setBaudRate(QSerialPort::Baud19200);
    setParity(QSerialPort::NoParity);
    setFlowControl(QSerialPort::NoFlowControl);
    connect(this, &RELAY::PingSignal, this, &RELAY::PingSlot); //, Qt::QueuedConnection);
    connect(this, &RELAY::SetRelaySignal, this, &RELAY::SetRelaySlot); //, Qt::QueuedConnection);
}

bool RELAY::Ping(const QString& portName)
{
    mutex.lock();
    emit PingSignal(portName);
    if (mutex.tryLock(500)) {
        mutex.unlock();
        emit showMessage("Коммутатор найден!", 1000);
        return true;
    }
    mutex.unlock();
    emit showMessage("Коммутатор не найден!", 1000);
    return false;
}

bool RELAY::SetRelay(int RelNum)
{
    mutex.lock();
    emit SetRelaySignal(RelNum);
    if (mutex.tryLock(500)) {
        mutex.unlock();
        emit showMessage("Коммутатор переключен!", 1000);
        return true;
    }
    mutex.unlock();
    emit showMessage("Не удалось переключить коммутатор!", 1000);
    return false;
}

void RELAY::PingSlot(const QString& portName)
{
    uint8_t tmp = 0;
    setPortName(portName);

    if (open(QIODevice::ReadWrite)) {
        write(Parcel(&tmp));
        waitForReadyRead(100);
        data = readAll();
        while (data.size() < 5) {
            waitForReadyRead(10);
            data.append(readAll());
        }
        close();
    }
    if (CheckData(data) & data[3] == char(55)) {
        mutex.unlock();
        return;
    }
}

void RELAY::SetRelaySlot(int RelNum)
{
    uint64_t r = pow(2.0, RelNum);
    //    endswap((uint32_t*)&r);
    r = 1 + (r << 8);

    if (open(QIODevice::ReadWrite)) {
        write(Parcel(&r, 5));
        waitForReadyRead(100);
        data = readAll();
        while (data.size() < 5) {
            waitForReadyRead(10);
            data.append(readAll());
        }
        close();
    }
    if (CheckData(data) & data[3] == char(1)) {
        mutex.unlock();
        return;
    }
}

bool RELAY::CheckData(QByteArray& Data)
{
    qDebug() << "CheckData" << Data.toHex().toUpper();
    if (Data.size() > 3) {
        if (Data.at(0) == -86 && Data.at(1) == 85) {
            if (int(Data[2]) == Data.size()) {
                if (uint8_t(Data[Data.size() - 1]) == CalcCrc(Data)) {
                    return true;
                }
            }
        }
    }
    return false;
}

QByteArray& RELAY::Parcel(void* Data, uint8_t Len)
{
    int8_t* p8 = (int8_t*)Data;
    data.clear();
    data.push_back(85); //старт 0x55
    data.push_back(-86); //старт 0xAA
    data.push_back(Len + 4); //размер посылки
    for (int i = 0; i < Len; ++i) {
        data.push_back(*p8++); //данные
    }
    data.push_back(1); //байт для crc
    data[data.size() - 1] = CalcCrc(data); //crc

    qDebug() << "Parcel" << data.toHex().toUpper();

    return data;
}

char RELAY::CalcCrc(QByteArray& Data)
{
    uint8_t crc8 = 0;
    for (uint16_t i = 0; i < Data.size() - 1; ++i) {
        crc8 ^= Data[i];
        for (uint16_t j = 0; j < 8; ++j) {
            if (crc8 & 0x80) {
                crc8 = (crc8 << 1) ^ POLYNOMIAL;
            }
            else {
                crc8 <<= 1;
            }
        }
    }
    return crc8;
}
