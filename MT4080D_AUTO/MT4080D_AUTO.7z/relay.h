#ifndef MY_PROTOCOL_H
#define MY_PROTOCOL_H

#include <QObject>
#include <QVector>
#include <QDebug>
#include <QThread>
#include <QtSerialPort>
#include <stdint.h>

#define POLYNOMIAL 0x1D // x^8 + x^4 + x^3 + x^2 + 1

class RELAY : public QSerialPort {
    Q_OBJECT

public:
    explicit RELAY(QObject* parent = 0);
    //    QSerialPort port;

    char CalcCrc(QByteArray& Data);
    QByteArray& Parcel(void* Data, uint8_t Len = 1);
    bool CheckData(QByteArray& Data);

    bool Ping(const QString& portName);
    bool SetRelay(int RelNum);

signals:
    void PingSignal(const QString& portName);
    void SetRelaySignal(int RelNum);
    void showMessage(const QString& text, int timeout = 0);

private:
    QMutex mutex;
    QByteArray data;

    void PingSlot(const QString& portName);
    void SetRelaySlot(int RelNum);
};

#endif // MY_PROTOCOL_H
