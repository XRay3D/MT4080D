#include "rele.h"

RELE::RELE(QObject* parent)
    : QSerialPort(parent)
//    , port(parent)
{
    setBaudRate(9600);
    setParity(QSerialPort::NoParity);
    setFlowControl(QSerialPort::NoFlowControl);
    setPortName("COM4");
    connect(this, &RELE::PingSignal, this, &RELE::PingSlot); //, Qt::QueuedConnection);
    connect(this, &RELE::SetRelaySignal, this, &RELE::SetRelaySlot); //, Qt::QueuedConnection);
}

bool RELE::Ping(const QString& portName)
{
    mutex.lock();
    emit PingSignal(portName);
    if (mutex.tryLock(150)) {
        mutex.unlock();
        return true;
    }
    mutex.unlock();
    return false;

    //    if (open(QIODevice::ReadWrite)) {
    //        uint8_t tmp = 0;
    //        write(Parcel(&tmp));
    //        waitForReadyRead(100);
    //        waitForReadyRead(10);
    //        data = readAll();
    //        close();
    //    }
    //    if (CheckData(data) & data[3] == char(55)) {
    //        qDebug() << "Ping OK";
    //        return true;
    //    }
    //    qDebug() << "Ping ERR";
    //    return false;
}

bool RELE::SetRelay(int RelNum)
{
    mutex.lock();
    emit SetRelaySignal(RelNum);
    if (mutex.tryLock(150)) {
        mutex.unlock();
        return true;
    }
    mutex.unlock();
    return false;

    //    uint64_t r = pow(2.0, RelNum);
    //    r = 1 + (r << 8);
    //    uint8_t* p = (uint8_t*)&r;
    //    qSwap(p[1], p[4]);
    //    qSwap(p[2], p[3]);
    //    if (open(QIODevice::ReadWrite)) {
    //        write(Parcel(&r, 5));
    //        waitForReadyRead(100);
    //        waitForReadyRead(10);
    //        data = readAll();
    //        close();
    //    }
    //    if (CheckData(data) & data[3] == char(1)) {
    //        qDebug() << "SetRel Ok" << RelNum;
    //        return true;
    //    }
    //    qDebug() << "SetRel Err" << RelNum;
    //    return false;
}

void RELE::PingSlot(const QString& portName)
{
    setPortName(portName);
    if (open(QIODevice::ReadWrite)) {
        uint8_t tmp = 0;
        write(Parcel(&tmp));
        waitForReadyRead(100);
        waitForReadyRead(10);
        data = readAll();
        close();
        if (CheckData(data) & data[3] == char(55)) {
            mutex.unlock();
            qDebug() << "PingSlot Ok";
            return;
        }
    }
    qDebug() << "PingSlot err";
}

template <class T>
void endswap(T* objp) //little endian <> big endian
{
    unsigned char* memp = reinterpret_cast<unsigned char*>(objp);
    std::reverse(memp, memp + sizeof(T));
}

void RELE::SetRelaySlot(int RelNum)
{
    uint64_t r = pow(2.0, RelNum);
    endswap((uint32_t*)&r);
    r = 1 + (r << 8);
    if (open(QIODevice::ReadWrite)) {
        write(Parcel(&r, 5));
        waitForReadyRead(100);
        waitForReadyRead(10);
        data = readAll();
        close();
    }
    if (CheckData(data) & data[3] == char(1)) {
        qDebug() << "SetReleSlot Ok" << RelNum;
        mutex.unlock();
        return;
    }
    qDebug() << "SetReleSlot Err" << RelNum;
    return;
}

bool RELE::CheckData(QByteArray& Data)
{
    //    qDebug() << Data.toHex().toUpper();

    if (Data.size() > 3) {
        if (Data.at(0) == -86 && Data.at(1) == 85) {
            if (int(Data[2]) == Data.size()) {
                if (uint8_t(Data[Data.size() - 1]) == CalcCrc(Data)) {
                    return true;
                }
            }
        }
    }
    return false;
}

QByteArray& RELE::Parcel(void* Data, uint8_t Len)
{
    int8_t* p8 = (int8_t*)Data;
    data.clear();
    data.push_back(85); //старт 0x55
    data.push_back(-86); //старт 0xAA
    data.push_back(Len + 4); //размер посылки
    for (int i = 0; i < Len; ++i) {
        data.push_back(*p8++); //данные
    }
    data.push_back(1); //байт для crc
    data[data.size() - 1] = CalcCrc(data); //crc

    //    qDebug() << data.toHex().toUpper();

    return data;
}

char RELE::CalcCrc(QByteArray& Data)
{
    uint8_t crc8 = 0;
    for (uint16_t i = 0; i < Data.size() - 1; ++i) {
        crc8 ^= Data[i];
        for (uint16_t j = 0; j < 8; ++j) {
            if (crc8 & 0x80) {
                crc8 = (crc8 << 1) ^ POLYNOMIAL;
            }
            else {
                crc8 <<= 1;
            }
        }
    }
    return crc8;
}
