#ifndef MY_PROTOCOL_H
#define MY_PROTOCOL_H

#include <QObject>
#include <QVector>
#include <QDebug>
#include <QThread>
#include <QtSerialPort>
#include <stdint.h>

#define POLYNOMIAL 0x1D // x^8 + x^4 + x^3 + x^2 + 1

class RELE : public QSerialPort {
    Q_OBJECT

public:
    explicit RELE(QObject* parent = 0);
    //    QSerialPort port;

signals:
    void PingSignal(const QString& portName);
    void SetRelaySignal(int RelNum);

public:
    QByteArray data;
    char CalcCrc(QByteArray& Data);
    QByteArray& Parcel(void* Data, uint8_t Len = 1);
    bool CheckData(QByteArray& Data);

    bool Ping(const QString& portName);
    bool SetRelay(int RelNum);

private:
    QMutex mutex;

    void PingSlot(const QString& portName);
    void SetRelaySlot(int RelNum);
};

#endif // MY_PROTOCOL_H
